package com.example.services;

import com.example.domains.Pesado;
import com.example.domains.dtos.PesadoDTO;
import com.example.repositories.PesadoRepository;
import com.example.services.exceptions.DataIntegrityViolationException;
import com.example.services.exceptions.ObjectNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PesadoService {

    @Autowired
    private PesadoRepository pesadoRepo;

    public List<PesadoDTO> findAll(){
        return pesadoRepo.findAll().stream().map(obj -> new PesadoDTO(obj)).collect(Collectors.toList());
    }

    public Pesado findById(Long id){
        Optional<Pesado> obj = pesadoRepo.findById(id);
        return obj.orElseThrow(() -> new ObjectNotFoundException("Objeto não encontrado! ID: "+id));
    }

    public Pesado findByChassis(String chassis){
        Optional<Pesado> obj = pesadoRepo.findByChassis(chassis);
        return obj.orElseThrow(() -> new ObjectNotFoundException("Objeto não encontrado! ID: "+chassis));
    }

    public Pesado findByDono(String dono){
        Optional<Pesado> obj = pesadoRepo.findByDono(dono);
        return obj.orElseThrow(() -> new ObjectNotFoundException("Objeto não encontrado! ID: "+dono));
    }

    public Pesado create(PesadoDTO dto) {
        dto.setId(null);
        Pesado obj = new Pesado(dto);
        return pesadoRepo.save(obj);
    }

    public Pesado update(Long id, PesadoDTO objDto) {
        objDto.setId(id);
        Pesado oldObj = findById(id);
        oldObj = new Pesado(objDto);
        return pesadoRepo.save(oldObj);
    }

    public void delete(Long id) {
        Pesado obj = findById(id);
        if (obj.getServicos().size() > 0) {
            throw new DataIntegrityViolationException("Veiculo não pode ser deletado pois possui ordens de serviço vinculadas!");
        }
        pesadoRepo.deleteById(id);
    }

    private void ValidaChassis(PesadoDTO objDto){
        Optional<Pesado> obj = pesadoRepo.findByChassis(objDto.getChassis());
        if(obj.isPresent() && obj.get().getId() != objDto.getId()){
            throw new DataIntegrityViolationException("Chassis já cadastrado no sistema");
        }
    }

}
