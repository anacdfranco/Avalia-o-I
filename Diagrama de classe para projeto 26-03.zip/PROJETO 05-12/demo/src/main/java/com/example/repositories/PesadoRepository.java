package com.example.repositories;

import com.example.domains.Leve;
import com.example.domains.Pesado;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PesadoRepository extends JpaRepository<Pesado, Long> {

    Optional<Pesado> findByChassis(String chassis);
    Optional<Pesado> findByDono(String dono);
}
