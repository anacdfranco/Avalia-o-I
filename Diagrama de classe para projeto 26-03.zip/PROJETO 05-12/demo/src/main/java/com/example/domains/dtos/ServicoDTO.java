package com.example.domains.dtos;

import com.example.domains.Servico;
import com.example.domains.Veiculo;
import com.example.domains.enums.TipoServico;
import com.example.domains.enums.Urgencia;
import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;
import java.util.UUID;

public class ServicoDTO {

    private UUID id;

    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate dataInicio = LocalDate.now();

    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate dataFim;

    @NotNull(message = "O campo valor da ordem não pode ser nulo")
    @Digits(integer = 15 , fraction = 2)
    private Double valor;

    @NotNull(message = "O campo tipo do serviço não pode ser nulo")
    private Integer tipoServico;

    @NotNull(message = "O campo urgência do serviço não pode ser nulo")
    private Integer urgencia;

    @NotNull(message = "O campo do veiculo não pode ser nulo")
    private Long veiculo;

    private String nomeDono;

    public ServicoDTO() {}

    public ServicoDTO(Servico servico) {
        this.id = servico.getId();
        this.dataInicio = servico.getDataInicio();
        this.dataFim = servico.getDataFim();
        this.valor = servico.getValor();
        this.tipoServico = servico.getTipoServico().getId();
        this.urgencia = servico.getUrgencia().getId();
        this.veiculo = servico.getVeiculo().getId();
        this.nomeDono = servico.getVeiculo().getDono();
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public LocalDate getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(LocalDate dataInicio) {
        this.dataInicio = dataInicio;
    }

    public LocalDate getDataFim() {
        return dataFim;
    }

    public void setDataFim(LocalDate dataFim) {
        this.dataFim = dataFim;
    }

    public @NotNull(message = "O campo valor da ordem não pode ser nulo") @Digits(integer = 15, fraction = 2) Double getValor() {
        return valor;
    }

    public void setValor(@NotNull(message = "O campo valor da ordem não pode ser nulo") @Digits(integer = 15, fraction = 2) Double valor) {
        this.valor = valor;
    }

    public @NotNull(message = "O campo tipo do serviço não pode ser nulo") Integer getTipoServico() {
        return tipoServico;
    }

    public void setTipoServico(@NotNull(message = "O campo tipo do serviço não pode ser nulo") Integer tipoServico) {
        this.tipoServico = tipoServico;
    }

    public @NotNull(message = "O campo urgência do serviço não pode ser nulo") Integer getUrgencia() {
        return urgencia;
    }

    public void setUrgencia(@NotNull(message = "O campo urgência do serviço não pode ser nulo") Integer urgencia) {
        this.urgencia = urgencia;
    }

    public @NotNull(message = "O campo do veiculo não pode ser nulo") Long getVeiculo() {
        return veiculo;
    }

    public void setVeiculo(@NotNull(message = "O campo do veiculo não pode ser nulo") Long veiculo) {
        this.veiculo = veiculo;
    }

    public String getNomeDono() {
        return nomeDono;
    }

    public void setNomeDono(String nomeDono) {
        this.nomeDono = nomeDono;
    }
}
