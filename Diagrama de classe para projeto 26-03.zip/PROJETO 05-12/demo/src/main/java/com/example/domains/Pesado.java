package com.example.domains;

import com.example.domains.dtos.LeveDTO;
import com.example.domains.dtos.PesadoDTO;
import com.example.domains.enums.TipoVeiculo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Entity
public class Pesado extends Veiculo{

    @JsonIgnore
    @OneToMany
    private List<Servico> servicos = new ArrayList<>();

    public Pesado(Long id, String chassis, String dono, String cor, String marca, String modelo) {
        super(id, chassis, dono, cor, marca, modelo);
        addTipoVeiculo(TipoVeiculo.CAMINHAO);
    }

    public Pesado(PesadoDTO obj){
            this.id = obj.getId();
            this.chassis = obj.getChassis();
            this.dono = obj.getDono();
            this.cor = obj.getCor();
            this.marca = obj.getMarca();
            this.modelo = obj.getModelo();
            this.tipoVeiculo = obj.getTipoVeiculo().stream().map(x -> x.getId()).collect(Collectors.toSet());
            addTipoVeiculo(TipoVeiculo.CAMINHAO);
    }

    public List<Servico> getServicos() {
        return servicos;
    }

    public void setServicos(List<Servico> servicos) {
        this.servicos = servicos;
    }
}
