package com.example.services;

import com.example.domains.Leve;
import com.example.domains.dtos.LeveDTO;
import com.example.repositories.LeveRepository;
import com.example.services.exceptions.DataIntegrityViolationException;
import com.example.services.exceptions.ObjectNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class LeveService {

    @Autowired
    private LeveRepository leveRepo;

    public List<LeveDTO> findAll(){
        return leveRepo.findAll().stream().map(obj -> new LeveDTO(obj)).collect(Collectors.toList());
    }

    public Leve findById(Long id){
        Optional<Leve> obj = leveRepo.findById(id);
        return obj.orElseThrow(() -> new ObjectNotFoundException("Objeto não encontrado! ID: "+id));
    }

    public Leve findByChassis(String chassis){
        Optional<Leve> obj = leveRepo.findByChassis(chassis);
        return obj.orElseThrow(() -> new ObjectNotFoundException("Objeto não encontrado! ID: "+chassis));
    }

    public Leve findByDono(String dono){
        Optional<Leve> obj = leveRepo.findByDono(dono);
        return obj.orElseThrow(() -> new ObjectNotFoundException("Objeto não encontrado! ID: "+dono));
    }

    public Leve create(LeveDTO dto) {
        dto.setId(null);
        Leve obj = new Leve(dto);
        return leveRepo.save(obj);
    }

    public Leve update(Long id, LeveDTO objDto) {
        objDto.setId(id);
        Leve oldObj = findById(id);
        oldObj = new Leve(objDto);
        return leveRepo.save(oldObj);
    }

    public void delete(Long id) {
        Leve obj = findById(id);
        if (obj.getServicos().size() > 0) {
            throw new DataIntegrityViolationException("Veiculo não pode ser deletado pois possui ordens de serviço vinculadas!");
        }
        leveRepo.deleteById(id);
    }

    private void ValidaChassis(LeveDTO objDto){
        Optional<Leve> obj = leveRepo.findByChassis(objDto.getChassis());
        if(obj.isPresent() && obj.get().getId() != objDto.getId()){
            throw new DataIntegrityViolationException("Chassis já cadastrado no sistema");
        }
    }

}
