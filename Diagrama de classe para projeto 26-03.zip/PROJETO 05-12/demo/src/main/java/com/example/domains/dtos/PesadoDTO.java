package com.example.domains.dtos;

import com.example.domains.Leve;
import com.example.domains.Pesado;
import com.example.domains.enums.TipoVeiculo;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

public class PesadoDTO {

    protected Long id;

    @NotNull(message = "O campo chassis não pode ser nulo")
    @NotBlank(message = "O campo chassis não pode estar vazio")
    protected String chassis;

    @NotNull(message = "O campo nome do dono não pode ser nulo")
    @NotBlank(message = "O campo nome do dono não pode estar vazio")
    protected String dono;

    @NotNull(message = "O campo cor não pode ser nulo")
    @NotBlank(message = "O campo cor não pode estar vazio")
    protected String cor;

    @NotNull(message = "O campo marca não pode ser nulo")
    @NotBlank(message = "O campo marca não pode estar vazio")
    protected String marca;

    @NotNull(message = "O campo modelo não pode ser nulo")
    @NotBlank(message = "O campo modelo não pode estar vazio")
    protected String modelo;

    protected Set<Integer> tipoVeiculo = new HashSet<>();

    public PesadoDTO() {}

    public PesadoDTO(Pesado obj) {
        this.id = obj.getId();
        this.chassis = obj.getChassis();
        this.dono = obj.getDono();
        this.cor = obj.getCor();
        this.marca = obj.getMarca();
        this.modelo = obj.getModelo();
        this.tipoVeiculo.stream().map(TipoVeiculo::toEnum).collect(Collectors.toSet());
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public @NotNull(message = "O campo chassis não pode ser nulo") @NotBlank(message = "O campo chassis não pode estar vazio") String getChassis() {
        return chassis;
    }

    public void setChassis(@NotNull(message = "O campo chassis não pode ser nulo") @NotBlank(message = "O campo chassis não pode estar vazio") String chassis) {
        this.chassis = chassis;
    }

    public @NotNull(message = "O campo nome do dono não pode ser nulo") @NotBlank(message = "O campo nome do dono não pode estar vazio") String getDono() {
        return dono;
    }

    public void setDono(@NotNull(message = "O campo nome do dono não pode ser nulo") @NotBlank(message = "O campo nome do dono não pode estar vazio") String dono) {
        this.dono = dono;
    }

    public @NotNull(message = "O campo cor não pode ser nulo") @NotBlank(message = "O campo cor não pode estar vazio") String getCor() {
        return cor;
    }

    public void setCor(@NotNull(message = "O campo cor não pode ser nulo") @NotBlank(message = "O campo cor não pode estar vazio") String cor) {
        this.cor = cor;
    }

    public @NotNull(message = "O campo marca não pode ser nulo") @NotBlank(message = "O campo marca não pode estar vazio") String getMarca() {
        return marca;
    }

    public void setMarca(@NotNull(message = "O campo marca não pode ser nulo") @NotBlank(message = "O campo marca não pode estar vazio") String marca) {
        this.marca = marca;
    }

    public @NotNull(message = "O campo modelo não pode ser nulo") @NotBlank(message = "O campo modelo não pode estar vazio") String getModelo() {
        return modelo;
    }

    public void setModelo(@NotNull(message = "O campo modelo não pode ser nulo") @NotBlank(message = "O campo modelo não pode estar vazio") String modelo) {
        this.modelo = modelo;
    }

    public Set<TipoVeiculo> getTipoVeiculo() {
        return tipoVeiculo == null ? Collections.emptySet() :
                tipoVeiculo.stream().map(TipoVeiculo::toEnum).collect(Collectors.toSet());
    }

    public void addTipoVeiculo(TipoVeiculo tipoVeiculo) {
        this.tipoVeiculo.add(tipoVeiculo.getId());
    }
}

