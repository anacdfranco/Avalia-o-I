package com.example.repositories;

import com.example.domains.Leve;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface LeveRepository extends JpaRepository<Leve, Long> {

    Optional<Leve> findByChassis(String chassis);
    Optional<Leve> findByDono(String dono);
}
