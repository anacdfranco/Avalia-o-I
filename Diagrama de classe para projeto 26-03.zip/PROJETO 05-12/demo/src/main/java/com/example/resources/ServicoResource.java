package com.example.resources;

import com.example.domains.Servico;
import com.example.domains.dtos.ServicoDTO;
import com.example.services.ServicoService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping(value = "/servico")
public class ServicoResource {

    @Autowired
    private ServicoService osService;

    @GetMapping
    public ResponseEntity<List<ServicoDTO>> findAll(){
        return ResponseEntity.ok().body(osService.findAll());
    }

    @GetMapping(value = "/{id}")
    public ResponseEntity<ServicoDTO> findById(@PathVariable UUID id){
        Servico obj = this.osService.findById(id);
        return ResponseEntity.ok().body(new ServicoDTO(obj));
    }

    @PostMapping
    public ResponseEntity<ServicoDTO> create(@Valid @RequestBody ServicoDTO objDto){
        Servico newObj = osService.create(objDto);
        URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(newObj.getId()).toUri();
        return ResponseEntity.created(uri).build();
    }

    @PostMapping(value = "/{id}")
    public ResponseEntity<ServicoDTO> update(@PathVariable UUID id, @Valid @RequestBody ServicoDTO objDto){
        Servico Obj = osService.update(id, objDto);
        return ResponseEntity.ok().body(new ServicoDTO(Obj));
    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<ServicoDTO> delete(@PathVariable UUID id){
        osService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
