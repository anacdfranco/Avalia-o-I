package com.example.domains.enums;

public enum TipoVeiculo {

    CARRO(0, "CARRO"), CAMINHAO(1   , "CAMINHAO");

    private Integer id;
    private String tipoVeiculo;

    TipoVeiculo(Integer id, String tipoVeiculo) {
        this.id = id;
        this.tipoVeiculo = tipoVeiculo;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTipoVeiculo() {
        return tipoVeiculo;
    }

    public void setTipoVeiculo(String tipoVeiculo) {
        this.tipoVeiculo = tipoVeiculo;
    }

    public static TipoVeiculo toEnum(Integer id){
        if(id==null) return null;
        for(TipoVeiculo x : TipoVeiculo.values()){
            if(id.equals(x.getId())){
                return x;
            }
        }
        throw new IllegalArgumentException("Tipo do veiculo inválido");
    }
}
