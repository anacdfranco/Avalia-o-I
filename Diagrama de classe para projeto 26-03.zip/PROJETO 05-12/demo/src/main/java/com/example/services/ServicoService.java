package com.example.services;

import com.example.domains.Leve;
import com.example.domains.Pesado;
import com.example.domains.Servico;
import com.example.domains.dtos.ServicoDTO;
import com.example.domains.enums.TipoServico;
import com.example.domains.enums.Urgencia;
import com.example.repositories.ServicoRepository;
import com.example.services.exceptions.DataIntegrityViolationException;
import com.example.services.exceptions.ObjectNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class ServicoService {

    @Autowired
    private ServicoRepository servicoRepo;

    @Autowired
    private LeveService leveService;

    @Autowired
    private PesadoService pesadoService;

    public Servico findById(UUID id){
        Optional<Servico> obj = servicoRepo.findById(id);
        return obj.orElseThrow(() -> new ObjectNotFoundException("Objeto não encontrado! ID: "+id));
    }

    public List<ServicoDTO> findAll(){
        return servicoRepo.findAll().stream().map(obj -> new ServicoDTO(obj)).collect(Collectors.toList());
    }

    private Servico novaOrdemdeServico(ServicoDTO obj){
        Leve leve = leveService.findById(obj.getVeiculo());
        Pesado pesado = pesadoService.findById(obj.getVeiculo());

        Servico os = new Servico();
        if(obj.getId() != null){
            os.setId(obj.getId());
        }

        os.setVeiculo(leve);
        os.setVeiculo(pesado);
        os.setTipoServico(TipoServico.toEnum(obj.getTipoServico()));
        os.setValor(obj.getValor());
        os.setUrgencia(Urgencia.toEnum(obj.getUrgencia()));
        return os;
    }

    public Servico create(ServicoDTO objDto){
        return servicoRepo.save(novaOrdemdeServico(objDto));
    }

    public Servico update(UUID id, ServicoDTO objDto){
        objDto.setId(id);
        Servico oldObj = findById(id);
        oldObj = novaOrdemdeServico(objDto);
        return servicoRepo.save(oldObj);
    }

    public void delete(UUID id) {
        Servico obj = findById(id);
        servicoRepo.deleteById(id);
    }
}
