package com.example.domains;

import com.example.domains.enums.TipoServico;
import com.example.domains.enums.TipoVeiculo;
import jakarta.persistence.*;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

@Entity
@Table(name = "veiculo")
public abstract class Veiculo {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_veiculo")
    protected Long id;

    @Column(unique = true)
    protected String chassis;

    protected String dono;
    protected String cor;
    protected String marca;
    protected String modelo;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name =" tipos_veiculos")
    protected Set<Integer> tipoVeiculo = new HashSet<>();

    public Veiculo() {}

    public Veiculo(Long id, String chassis,String dono, String cor, String marca, String modelo) {
        this.id = id;
        this.chassis = chassis;
        this.dono = dono;
        this.cor = cor;
        this.marca = marca;
        this.modelo = modelo;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getChassis() {
        return chassis;
    }

    public void setChassis(String chassis) {
        this.chassis = chassis;
    }

    public String getDono() {
        return dono;
    }

    public void setDono(String dono) {
        this.dono = dono;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public Set<TipoVeiculo> getTipoVeiculo() {
        return tipoVeiculo.stream().map(TipoVeiculo::toEnum).collect(Collectors.toSet());
    }

    public void addTipoVeiculo(TipoVeiculo tipoVeiculo) {
        this.tipoVeiculo.add(tipoVeiculo.getId());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Veiculo veiculo = (Veiculo) o;
        return Objects.equals(id, veiculo.id) && Objects.equals(chassis, veiculo.chassis);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, chassis);
    }
}
