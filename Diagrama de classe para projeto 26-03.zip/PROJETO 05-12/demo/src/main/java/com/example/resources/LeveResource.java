package com.example.resources;

import com.example.domains.Leve;
import com.example.domains.dtos.LeveDTO;
import com.example.services.LeveService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping(value = "/leve")
public class LeveResource {

    @Autowired
    private LeveService leveService;

    @GetMapping
    public ResponseEntity<List<LeveDTO>> findAll(){
        return ResponseEntity.ok().body(leveService.findAll());
    }

    @GetMapping(value = "/{id}")
    public ResponseEntity<LeveDTO> findById(@PathVariable Long id){
        Leve obj = this.leveService.findById(id);
        return ResponseEntity.ok().body(new LeveDTO(obj));
    }

    @GetMapping(value = "/chassis/{chassis}")
    public ResponseEntity<LeveDTO> findByChassis(@PathVariable String chassis){
        Leve obj = this.leveService.findByChassis(chassis);
        return ResponseEntity.ok().body(new LeveDTO(obj));
    }

    @GetMapping(value = "/dono/{dono}")
    public ResponseEntity<LeveDTO> findByDono(@PathVariable String dono){
        Leve obj = this.leveService.findByDono(dono);
        return ResponseEntity.ok().body(new LeveDTO(obj));
    }

    @PostMapping
    public ResponseEntity<LeveDTO> create(@Valid @RequestBody LeveDTO objDto){
        Leve newObj = leveService.create(objDto);
        URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(newObj.getId()).toUri();
        return ResponseEntity.created(uri).build();
    }

    @PostMapping(value = "/{id}")
    public ResponseEntity<LeveDTO> update(@PathVariable Long id, @Valid @RequestBody LeveDTO objDto){
        Leve Obj = leveService.update(id, objDto);
        return ResponseEntity.ok().body(new LeveDTO(Obj));
    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<LeveDTO> delete(@PathVariable Long id){
        leveService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
