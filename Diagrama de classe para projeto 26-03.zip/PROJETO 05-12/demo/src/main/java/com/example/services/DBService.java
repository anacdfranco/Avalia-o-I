package com.example.services;

import com.example.domains.*;
import com.example.domains.enums.*;
import com.example.repositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;

@Service
public class DBService {

    @Autowired
    private PecaRepository pecaRepo;

    @Autowired
    private MarcaRepository marcaRepo;

    @Autowired
    private FornecedorRepository fornecedorRepo;

    @Autowired
    private PesadoRepository pesadoRepo;

    @Autowired
    private LeveRepository leveRepo;

    @Autowired
    private ServicoRepository servicoRepo;

    public void initDB(){

        Marca marca01 = new Marca(null, "Rodobens Caminhões e Onibus", "Mercedes", new BigInteger("304512457587"));
        Marca marca02 = new Marca(null, "Volkswagen do Brasil Industria de Veiculos Automotores", "Volkswagen", new BigInteger("154785987526"));

        Fornecedor fornecedor01 = new Fornecedor(null, "Vannucci Importacao Exportacao e Com. de Pecas", "11623920000182", "Vannucci", new BigInteger("147038291117"));
        Fornecedor fornecedor02 = new Fornecedor(null, "Pacaembu Autopecas", "61295473000905", "Pacaembu", new BigInteger("647109389113"));

        Peca peca01 = new Peca(null, "Lona de Freio", new BigDecimal("77"), "MB 710", 2, "A.2.19", 87083090, "PC", "A6884203020", "Freio", "Lonas", LocalDate.of(2024,11,15), Disponibilidade.DISPONIVEL,  Estado.NOVO, marca01, fornecedor01);
        Peca peca02 = new Peca(null, "Retentor Cubo Dianteiro", new BigDecimal("95"), "VOLKS 8.160", 3, "B.7.23", 87149310, "PC", "00188BA", "Roda", "Retentores", LocalDate.of(2024, 11, 16    ), Disponibilidade.DISPONIVEL, Estado.NOVO, marca02, fornecedor02);

        Leve leve01 = new Leve(null, "51231554845", "João Paulo Rubens", "Branco", "Chevrolet", "S-10");

        Pesado pesado01 = new Pesado(null, "3515152126", "Ricardo Nunes", "Azul", "Mercedes", "1113");

        Servico os01 = new Servico(null, 1100.00,Urgencia.MEDIA, leve01,TipoServico.DIFERENCIAL);
        Servico os02 = new Servico(null, 12500.00, Urgencia.ALTA, pesado01, TipoServico.MOTOR);


        leveRepo.save(leve01);
        pesadoRepo.save(pesado01);
        servicoRepo.save(os01);
        servicoRepo.save(os02);
        marcaRepo.save(marca01);
        marcaRepo.save(marca02);
        fornecedorRepo.save(fornecedor01);
        fornecedorRepo.save(fornecedor02);
        pecaRepo.save(peca01);
        pecaRepo.save(peca02);
    }
}
