package com.example.domains;

import com.example.domains.dtos.LeveDTO;
import com.example.domains.enums.TipoVeiculo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.Entity;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Entity
public class Leve extends Veiculo {

    @JsonIgnore
    @OneToMany
    private List<Servico> servicos = new ArrayList<>();

    public Leve(Long id, String chassis, String dono, String cor, String marca, String modelo) {
        super(id, chassis, dono, cor, marca, modelo);
        addTipoVeiculo(TipoVeiculo.CARRO);
    }

    public Leve(LeveDTO obj){
        this.id = obj.getId();
        this.chassis = obj.getChassis();
        this.dono = obj.getDono();
        this.cor = obj.getCor();
        this.marca = obj.getMarca();
        this.modelo = obj.getModelo();
        this.tipoVeiculo = obj.getTipoVeiculo().stream().map(x -> x.getId()).collect(Collectors.toSet());
        addTipoVeiculo(TipoVeiculo.CARRO);
    }

    public List<Servico> getServicos() {
        return servicos;
    }

    public void setServicos(List<Servico> servicos) {
        this.servicos = servicos;
    }
}
