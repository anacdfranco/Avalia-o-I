package com.example.domains.enums;

public enum TipoServico {

    SUSPENSAO(0, "SUSPENSAO"), FUNILARIA(1, "FUNILARIA"), MOTOR(2, "MOTOR"), DIFERENCIAL(3, "DIFERENCIAL"),
    TRANSMISSAO(4, "TRANSMISSAO");

    private Integer id;
    private String tipoServico;

    TipoServico(Integer id, String tipoServico) {
        this.id = id;
        this.tipoServico = tipoServico;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTipoServico() {
        return tipoServico;
    }

    public void setTipoServico(String tipoServico) {
        this.tipoServico = tipoServico;
    }

    public static TipoServico toEnum(Integer id){
        if(id==null) return null;
        for(TipoServico x : TipoServico.values()){
            if(id.equals(x.getId())){
                return x;
            }
        }
        throw new IllegalArgumentException("Tipo de Serviço inválido");
    }
}
