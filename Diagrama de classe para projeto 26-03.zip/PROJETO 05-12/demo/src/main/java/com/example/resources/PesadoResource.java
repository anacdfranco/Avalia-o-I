package com.example.resources;

import com.example.domains.Pesado;
import com.example.domains.dtos.PesadoDTO;
import com.example.services.PesadoService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping(value = "/pesado")
public class PesadoResource {

    @Autowired
    private PesadoService pesadoService;

    @GetMapping
    public ResponseEntity<List<PesadoDTO>> findAll(){
        return ResponseEntity.ok().body(pesadoService.findAll());
    }

    @GetMapping(value = "/{id}")
    public ResponseEntity<PesadoDTO> findById(@PathVariable Long id){
        Pesado obj = this.pesadoService.findById(id);
        return ResponseEntity.ok().body(new PesadoDTO(obj));
    }

    @GetMapping(value = "/chassis/{chassis}")
    public ResponseEntity<PesadoDTO> findByChassis(@PathVariable String chassis){
        Pesado obj = this.pesadoService.findByChassis(chassis);
        return ResponseEntity.ok().body(new PesadoDTO(obj));
    }

    @GetMapping(value = "/dono/{dono}")
    public ResponseEntity<PesadoDTO> findByDono(@PathVariable String dono){
        Pesado obj = this.pesadoService.findByDono(dono);
        return ResponseEntity.ok().body(new PesadoDTO(obj));
    }

    @PostMapping
    public ResponseEntity<PesadoDTO> create(@Valid @RequestBody PesadoDTO objDto){
        Pesado newObj = pesadoService.create(objDto);
        URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(newObj.getId()).toUri();
        return ResponseEntity.created(uri).build();
    }

    @PostMapping(value = "/{id}")
    public ResponseEntity<PesadoDTO> update(@PathVariable Long id, @Valid @RequestBody PesadoDTO objDto){
        Pesado Obj = pesadoService.update(id, objDto);
        return ResponseEntity.ok().body(new PesadoDTO(Obj));
    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<PesadoDTO> delete(@PathVariable Long id){
        pesadoService.delete(id);
        return ResponseEntity.noContent().build();
    }
}